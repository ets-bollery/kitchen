<?php
/**
 * The default template for displaying portfolio content in single-portfolio.php template
 *
 * @package Striking
 * @since Striking 5.2
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('entry content'); ?>>
<?php if(theme_get_option('portfolio','featured_image')):?>
	<header>
		<?php echo theme_generator('portfolio_featured_image',$layout,$effect); ?>
	</header>
<?php endif; ?>
	<?php the_content(); ?>
	<?php wp_link_pages( array( 'before' => '<div class="page-link">' . __( 'Pages:', 'striking_front' ), 'after' => '</div>' ) ); ?>
	<footer>
	<?php edit_post_link(__('Edit', 'striking_front'),'<p class="entry_edit">','</p>'); ?>
<?php if(theme_get_option('portfolio','author')):echo theme_generator('blog_author_info');endif;?>
<?php if(theme_get_option('portfolio','related_recent')):?>
		<div class="related_recent_wrap">
			<div class="one_half">
				<?php echo theme_generator('portfolio_related_posts');?>
			</div>
			<div class="one_half last">
				<?php echo theme_generator('portfolio_recent_posts');?>
			</div>
			<div class="clearboth"></div>
		</div>
<?php endif;?>
<?php if(theme_get_option('portfolio','single_navigation')):?>
		<nav class="entry_navigation">
			<div class="nav-previous"><?php previous_post_link( '%link', '<span class="meta-nav">' . _x( '&larr;', 'Previous portfolio link', 'striking_front' ) . '</span> %title' ,false); ?></div>
			<div class="nav-next"><?php next_post_link( '%link', '%title <span class="meta-nav">' . _x( '&rarr;', 'Next portfolio link', 'striking_front' ) . '</span>' ,false); ?></div>
		</nav>
<?php endif;?>
	</footer>
	<div class="clearboth"></div>
</article>