<?php
return array(
	'theme_name' => 'Striking', 
	'theme_slug' => 'striking',
	'theme_version' => '5.1.9.2',
	'required_wp_version' => '3.1',
);